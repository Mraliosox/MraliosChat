const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";
const CHARLIE_UID = "charlie_789";
const CHAT_ID = "alice_123_bob_456";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read users, user_directory, or chats", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(
    unauthDb.collection("user_directory").where("isDiscoverable", "==", true).get()
  );
  await assertFails(
    unauthDb.collection("chats").where("participantIds", "array-contains", ALICE_UID).get()
  );
});

test("Owner can create/read own private user profile; another user is denied (PII isolation)", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      uid: ALICE_UID,
      email: "alice@example.com",
      displayName: "Alice",
      isOnline: true,
      lastSeen: new Date(),
    })
  );
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).get());

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).set({
      uid: ALICE_UID,
      email: "spoof@example.com",
      displayName: "Hacked",
      isOnline: true,
      lastSeen: new Date(),
    })
  );
});

test("Shadow field injection on user profile is rejected", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).set({
      uid: ALICE_UID,
      email: "alice@example.com",
      displayName: "Alice",
      isOnline: true,
      lastSeen: new Date(),
      isAdmin: true,
    })
  );
});

test("Authenticated user can query discoverable user_directory entries", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("user_directory").doc(ALICE_UID).set({
      uid: ALICE_UID,
      displayName: "Alice",
      isOnline: true,
      lastSeen: new Date(),
      isDiscoverable: true,
    })
  );

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertSucceeds(
    bobDb.collection("user_directory").where("isDiscoverable", "==", true).get()
  );
  // Unfiltered list must fail
  await assertFails(bobDb.collection("user_directory").get());
});

test("Only chat participants can read/write chat and send messages", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID).firestore();

  const now = new Date();
  await assertSucceeds(
    aliceDb.collection("chats").doc(CHAT_ID).set({
      participantIds: [ALICE_UID, BOB_UID],
      participantNames: { [ALICE_UID]: "Alice", [BOB_UID]: "Bob" },
      lastMessage: "Hey Bob!",
      lastSenderId: ALICE_UID,
      lastMessageAt: now,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Participants can query their chats
  await assertSucceeds(
    bobDb.collection("chats").where("participantIds", "array-contains", BOB_UID).get()
  );
  // Non-participant cannot read or query Alice & Bob's chat
  await assertFails(charlieDb.collection("chats").doc(CHAT_ID).get());
  await assertFails(charlieDb.collection("chats").get());

  // Bob can send a message in the chat
  await assertSucceeds(
    bobDb.collection("chats").doc(CHAT_ID).collection("messages").doc("msg_1").set({
      senderId: BOB_UID,
      senderName: "Bob",
      text: "Hello Alice!",
      participantIds: [ALICE_UID, BOB_UID],
      timestamp: new Date(),
    })
  );

  // Empty message must be rejected
  await assertFails(
    bobDb.collection("chats").doc(CHAT_ID).collection("messages").doc("msg_empty").set({
      senderId: BOB_UID,
      senderName: "Bob",
      text: "",
      participantIds: [ALICE_UID, BOB_UID],
      timestamp: new Date(),
    })
  );

  // Spoofed senderId must be rejected
  await assertFails(
    bobDb.collection("chats").doc(CHAT_ID).collection("messages").doc("msg_spoof").set({
      senderId: ALICE_UID,
      senderName: "Alice",
      text: "Spoofed!",
      participantIds: [ALICE_UID, BOB_UID],
      timestamp: new Date(),
    })
  );

  // Non-participant Charlie cannot read Bob's message, run an unfiltered list, query Alice's messages, or send messages
  await assertFails(
    charlieDb.collection("chats").doc(CHAT_ID).collection("messages").doc("msg_1").get()
  );
  await assertFails(
    charlieDb.collection("chats").doc(CHAT_ID).collection("messages").get()
  );
  await assertFails(
    charlieDb
      .collection("chats")
      .doc(CHAT_ID)
      .collection("messages")
      .where("participantIds", "array-contains", ALICE_UID)
      .get()
  );
  await assertFails(
    charlieDb.collection("chats").doc(CHAT_ID).collection("messages").doc("msg_charlie").set({
      senderId: CHARLIE_UID,
      senderName: "Charlie",
      text: "Intruder",
      participantIds: [ALICE_UID, BOB_UID],
      timestamp: new Date(),
    })
  );

  // Participants can list messages
  await assertSucceeds(
    aliceDb
      .collection("chats")
      .doc(CHAT_ID)
      .collection("messages")
      .where("participantIds", "array-contains", ALICE_UID)
      .get()
  );

  // Messages are immutable (update & non-expired delete denied)
  await assertFails(
    bobDb.collection("chats").doc(CHAT_ID).collection("messages").doc("msg_1").update({
      text: "Edited",
    })
  );
  await assertFails(
    bobDb.collection("chats").doc(CHAT_ID).collection("messages").doc("msg_1").delete()
  );

  // Voice message creation succeeds for participant with encrypted payload
  await assertSucceeds(
    aliceDb.collection("chats").doc(CHAT_ID).collection("messages").doc("msg_audio_1").set({
      senderId: ALICE_UID,
      senderName: "Alice",
      type: "audio",
      text: "",
      audioData: "E2E1:ZmFrZUF1ZGlvQnl0ZXM=",
      durationMs: 2500,
      expiresAtMillis: 0,
      participantIds: [ALICE_UID, BOB_UID],
      timestamp: new Date(),
    })
  );

  // Disappearing message cannot be deleted before expiresAtMillis, and CAN be deleted after
  const futureExpiry = Date.now() + 60000;
  await assertSucceeds(
    aliceDb.collection("chats").doc(CHAT_ID).collection("messages").doc("msg_exp_future").set({
      senderId: ALICE_UID,
      senderName: "Alice",
      type: "text",
      text: "E2E1:c2VjcmV0",
      expiresAtMillis: futureExpiry,
      participantIds: [ALICE_UID, BOB_UID],
      timestamp: new Date(),
    })
  );
  await assertFails(
    bobDb.collection("chats").doc(CHAT_ID).collection("messages").doc("msg_exp_future").delete()
  );

  const pastExpiry = Date.now() - 5000;
  await assertSucceeds(
    aliceDb.collection("chats").doc(CHAT_ID).collection("messages").doc("msg_exp_past").set({
      senderId: ALICE_UID,
      senderName: "Alice",
      type: "text",
      text: "E2E1:ZXhwaXJlZA==",
      expiresAtMillis: pastExpiry,
      participantIds: [ALICE_UID, BOB_UID],
      timestamp: new Date(),
    })
  );
  // Non-participant still cannot delete even when expired
  await assertFails(
    charlieDb.collection("chats").doc(CHAT_ID).collection("messages").doc("msg_exp_past").delete()
  );
  // Participant can delete expired message
  await assertSucceeds(
    bobDb.collection("chats").doc(CHAT_ID).collection("messages").doc("msg_exp_past").delete()
  );
});
