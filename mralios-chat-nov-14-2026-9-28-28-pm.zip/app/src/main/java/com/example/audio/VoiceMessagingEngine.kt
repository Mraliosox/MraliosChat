package com.example.audio

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import com.example.security.CryptoUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

data class VoicePlaybackState(
    val playingMessageId: String? = null,
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val progress: Float = 0f,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
)

data class RecordedVoiceClip(
    val encryptedPayload: String,
    val durationMs: Long,
)

class VoiceMessagingEngine(
    private val context: Context,
    private val scope: CoroutineScope,
) {
    private val appContext = context.applicationContext

    private var mediaRecorder: MediaRecorder? = null
    private var activeRecordFile: File? = null
    private var recordingStartMs: Long = 0L
    private var recordingTickerJob: Job? = null

    private var mediaPlayer: MediaPlayer? = null
    private var activePlaybackFile: File? = null
    private var playbackTickerJob: Job? = null

    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording.asStateFlow()

    private val _recordingElapsedMs = MutableStateFlow(0L)
    val recordingElapsedMs: StateFlow<Long> = _recordingElapsedMs.asStateFlow()

    private val _playbackState = MutableStateFlow(VoicePlaybackState())
    val playbackState: StateFlow<VoicePlaybackState> = _playbackState.asStateFlow()

    fun startRecording(onMaxDurationReached: () -> Unit): Boolean {
        if (_isRecording.value) return false
        stopPlayback()

        val tempFile = File(appContext.cacheDir, "mralios_rec_${UUID.randomUUID()}.m4a")
        val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(appContext)
        } else {
            @Suppress("DEPRECATION")
            MediaRecorder()
        }

        return try {
            recorder.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioSamplingRate(44100)
                setAudioEncodingBitRate(128000)
                setOutputFile(tempFile.absolutePath)
                prepare()
                start()
            }
            mediaRecorder = recorder
            activeRecordFile = tempFile
            recordingStartMs = System.currentTimeMillis()
            _isRecording.value = true
            _recordingElapsedMs.value = 0L

            recordingTickerJob?.cancel()
            recordingTickerJob = scope.launch(Dispatchers.Main) {
                while (_isRecording.value) {
                    val elapsed = System.currentTimeMillis() - recordingStartMs
                    _recordingElapsedMs.value = elapsed
                    if (elapsed >= MAX_RECORDING_MS) {
                        onMaxDurationReached()
                        break
                    }
                    delay(100L)
                }
            }
            true
        } catch (_: Exception) {
            runCatching { recorder.release() }
            tempFile.delete()
            mediaRecorder = null
            activeRecordFile = null
            _isRecording.value = false
            false
        }
    }

    fun stopAndEncryptRecording(chatId: String): RecordedVoiceClip? {
        if (!_isRecording.value) return null
        recordingTickerJob?.cancel()
        recordingTickerJob = null
        _isRecording.value = false

        val elapsedMs = (System.currentTimeMillis() - recordingStartMs).coerceAtLeast(0L)
        _recordingElapsedMs.value = 0L

        val recorder = mediaRecorder
        mediaRecorder = null
        val file = activeRecordFile
        activeRecordFile = null

        try {
            recorder?.stop()
        } catch (_: Exception) {
            file?.delete()
            runCatching { recorder?.release() }
            return null
        }
        runCatching { recorder?.release() }

        if (file == null || !file.exists() || elapsedMs < MIN_RECORDING_MS) {
            file?.delete()
            return null
        }

        return try {
            val bytes = file.readBytes()
            file.delete()
            if (bytes.isEmpty()) return null
            val encrypted = CryptoUtils.encryptBytes(bytes, chatId)
            if (encrypted.length > MAX_ENCRYPTED_PAYLOAD_CHARS) {
                return null
            }
            RecordedVoiceClip(
                encryptedPayload = encrypted,
                durationMs = elapsedMs,
            )
        } catch (_: Exception) {
            file.delete()
            null
        }
    }

    fun cancelRecording() {
        recordingTickerJob?.cancel()
        recordingTickerJob = null
        _isRecording.value = false
        _recordingElapsedMs.value = 0L
        runCatching { mediaRecorder?.stop() }
        runCatching { mediaRecorder?.release() }
        mediaRecorder = null
        activeRecordFile?.delete()
        activeRecordFile = null
    }

    fun togglePlayback(
        messageId: String,
        encryptedAudioPayload: String,
        chatId: String,
        fallbackDurationMs: Long,
        onError: (String) -> Unit,
    ) {
        val current = _playbackState.value
        if (current.playingMessageId == messageId) {
            val player = mediaPlayer
            if (player != null) {
                if (player.isPlaying) {
                    player.pause()
                    _playbackState.value = current.copy(isPlaying = false)
                } else {
                    player.start()
                    _playbackState.value = current.copy(isPlaying = true)
                    startPlaybackTicker(messageId)
                }
                return
            }
        }

        stopPlayback()
        _playbackState.value = VoicePlaybackState(
            playingMessageId = messageId,
            isPlaying = false,
            isBuffering = true,
            progress = 0f,
            positionMs = 0L,
            durationMs = fallbackDurationMs,
        )

        val audioBytes = CryptoUtils.decryptBytes(encryptedAudioPayload, chatId)
        if (audioBytes == null || audioBytes.isEmpty()) {
            _playbackState.value = VoicePlaybackState()
            onError("Unable to decrypt voice note")
            return
        }

        val tempFile = File(appContext.cacheDir, "mralios_play_${UUID.randomUUID()}.m4a")
        try {
            tempFile.writeBytes(audioBytes)
            val player = MediaPlayer().apply {
                setDataSource(tempFile.absolutePath)
                setOnPreparedListener { mp ->
                    val dur = mp.duration.toLong().coerceAtLeast(fallbackDurationMs).coerceAtLeast(1L)
                    mp.start()
                    _playbackState.value = VoicePlaybackState(
                        playingMessageId = messageId,
                        isPlaying = true,
                        isBuffering = false,
                        progress = 0f,
                        positionMs = 0L,
                        durationMs = dur,
                    )
                    startPlaybackTicker(messageId)
                }
                setOnCompletionListener {
                    stopPlayback()
                }
                setOnErrorListener { _, _, _ ->
                    stopPlayback()
                    onError("Audio playback error")
                    true
                }
                prepareAsync()
            }
            mediaPlayer = player
            activePlaybackFile = tempFile
        } catch (_: Exception) {
            tempFile.delete()
            stopPlayback()
            onError("Failed to prepare audio playback")
        }
    }

    private fun startPlaybackTicker(messageId: String) {
        playbackTickerJob?.cancel()
        playbackTickerJob = scope.launch(Dispatchers.Main) {
            while (true) {
                val player = mediaPlayer ?: break
                if (_playbackState.value.playingMessageId != messageId) break
                if (!player.isPlaying) break
                val dur = player.duration.toLong().coerceAtLeast(1L)
                val pos = player.currentPosition.toLong().coerceIn(0L, dur)
                _playbackState.value = _playbackState.value.copy(
                    isPlaying = true,
                    isBuffering = false,
                    positionMs = pos,
                    durationMs = dur,
                    progress = (pos.toFloat() / dur.toFloat()).coerceIn(0f, 1f),
                )
                delay(80L)
            }
        }
    }

    fun stopPlayback() {
        playbackTickerJob?.cancel()
        playbackTickerJob = null
        runCatching {
            if (mediaPlayer?.isPlaying == true) {
                mediaPlayer?.stop()
            }
            mediaPlayer?.release()
        }
        mediaPlayer = null
        activePlaybackFile?.delete()
        activePlaybackFile = null
        _playbackState.value = VoicePlaybackState()
    }

    fun release() {
        cancelRecording()
        stopPlayback()
    }

    companion object {
        const val MIN_RECORDING_MS = 1000L
        const val MAX_RECORDING_MS = 35_000L
        private const val MAX_ENCRYPTED_PAYLOAD_CHARS = 880_000
    }
}
