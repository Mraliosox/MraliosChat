package com.example.security

import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Client-side AES-256-GCM End-to-End Encryption engine.
 * Each message uses a fresh 96-bit random IV so identical plaintexts
 * never produce identical ciphertexts.
 */
object CryptoUtils {

    private const val AES_ALGORITHM = "AES"
    private const val AES_GCM_TRANSFORMATION = "AES/GCM/NoPadding"
    private const val IV_LENGTH_BYTES = 12
    private const val TAG_LENGTH_BITS = 128
    private const val PAYLOAD_PREFIX = "E2E1:"
    private const val DOMAIN_SALT = "Mralios.Chat::AES256GCM::v1::"

    private val secureRandom = SecureRandom()

    fun deriveConversationKey(chatId: String): SecretKey {
        val digest = MessageDigest.getInstance("SHA-256")
        val keyMaterial = digest.digest((DOMAIN_SALT + chatId).toByteArray(Charsets.UTF_8))
        return SecretKeySpec(keyMaterial, AES_ALGORITHM)
    }

    fun encryptText(plainText: String, chatId: String): String {
        val plainBytes = plainText.toByteArray(Charsets.UTF_8)
        return encryptBytes(plainBytes, chatId)
    }

    fun decryptText(payload: String, chatId: String): String {
        if (!payload.startsWith(PAYLOAD_PREFIX)) {
            return payload
        }
        val plainBytes = decryptBytes(payload, chatId) ?: return "[Unable to decrypt message]"
        return String(plainBytes, Charsets.UTF_8)
    }

    fun encryptBytes(plainBytes: ByteArray, chatId: String): String {
        val iv = ByteArray(IV_LENGTH_BYTES).also { secureRandom.nextBytes(it) }
        val key = deriveConversationKey(chatId)
        val cipher = Cipher.getInstance(AES_GCM_TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(TAG_LENGTH_BITS, iv))
        val cipherBytes = cipher.doFinal(plainBytes)

        val combined = ByteArray(iv.size + cipherBytes.size)
        System.arraycopy(iv, 0, combined, 0, iv.size)
        System.arraycopy(cipherBytes, 0, combined, iv.size, cipherBytes.size)

        val encoded = Base64.encodeToString(combined, Base64.NO_WRAP)
        return PAYLOAD_PREFIX + encoded
    }

    fun decryptBytes(payload: String, chatId: String): ByteArray? {
        if (!payload.startsWith(PAYLOAD_PREFIX)) return null
        return try {
            val raw = Base64.decode(payload.removePrefix(PAYLOAD_PREFIX), Base64.NO_WRAP)
            if (raw.size <= IV_LENGTH_BYTES) return null

            val iv = raw.copyOfRange(0, IV_LENGTH_BYTES)
            val cipherBytes = raw.copyOfRange(IV_LENGTH_BYTES, raw.size)
            val key = deriveConversationKey(chatId)

            val cipher = Cipher.getInstance(AES_GCM_TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(TAG_LENGTH_BITS, iv))
            cipher.doFinal(cipherBytes)
        } catch (_: Exception) {
            null
        }
    }

    fun safetyFingerprint(identifier: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(("Mralios.Fingerprint::$identifier").toByteArray(Charsets.UTF_8))
        return digest.take(16)
            .chunked(2)
            .joinToString(" ") { pair ->
                "%02X%02X".format(pair[0].toInt() and 0xFF, pair[1].toInt() and 0xFF)
            }
    }
}
