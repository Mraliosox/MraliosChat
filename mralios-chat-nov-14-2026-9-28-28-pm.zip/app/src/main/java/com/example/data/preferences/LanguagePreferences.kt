package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "mralios_settings"
)

enum class AppLanguage(val code: String, val isRtl: Boolean) {
    ENGLISH("en", isRtl = false),
    ARABIC("ar", isRtl = true);

    companion object {
        fun fromCode(code: String?): AppLanguage {
            return entries.firstOrNull { it.code == code } ?: ENGLISH
        }
    }
}

class LanguagePreferences(private val context: Context) {
    private val languageKey = stringPreferencesKey("app_language")
    private val biometricLockKey = booleanPreferencesKey("biometric_lock_enabled")

    val languageFlow: Flow<AppLanguage> = context.applicationContext.settingsDataStore.data
        .map { prefs -> AppLanguage.fromCode(prefs[languageKey]) }

    val biometricLockFlow: Flow<Boolean> = context.applicationContext.settingsDataStore.data
        .map { prefs -> prefs[biometricLockKey] ?: true }

    suspend fun setLanguage(language: AppLanguage) {
        context.applicationContext.settingsDataStore.edit { prefs ->
            prefs[languageKey] = language.code
        }
    }

    suspend fun setBiometricLockEnabled(enabled: Boolean) {
        context.applicationContext.settingsDataStore.edit { prefs ->
            prefs[biometricLockKey] = enabled
        }
    }
}
