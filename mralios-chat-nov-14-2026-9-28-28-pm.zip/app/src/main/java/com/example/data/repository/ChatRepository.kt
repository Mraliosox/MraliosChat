package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.firebase.OperationType
import com.example.data.firebase.handleFirestoreError
import com.example.data.firebase.unwrapFirestoreException
import com.example.data.model.ChatMessage
import com.example.data.model.ChatSummary
import com.example.data.model.DirectoryUser
import com.example.data.model.UserProfile
import com.example.security.CryptoUtils
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class ChatRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth,
) {
    constructor(context: Context) : this(
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        auth = Firebase.auth
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in before accessing Firestore.")
    }

    suspend fun syncCurrentUserProfile(
        isOnline: Boolean = true,
        customDisplayName: String? = null,
    ): Result<Unit> {
        val user = auth.currentUser ?: return Result.failure(
            IllegalStateException("Cannot sync profile while unauthenticated")
        )
        val uid = user.uid
        val resolvedName = customDisplayName?.trim()?.takeIf { it.isNotEmpty() }
            ?: user.displayName?.trim()?.takeIf { it.isNotEmpty() }
            ?: user.email?.substringBefore("@")?.takeIf { it.isNotBlank() }
            ?: "Mralios User"
        val resolvedEmail = user.email?.trim()?.takeIf { it.length >= 3 }
            ?: "${uid.take(16)}@mralios.chat"

        val privateRef = db.collection(USERS_COLLECTION).document(uid)
        val publicRef = db.collection(USER_DIRECTORY_COLLECTION).document(uid)

        val privatePayload = mapOf(
            "uid" to uid,
            "email" to resolvedEmail,
            "displayName" to resolvedName.take(60),
            "isOnline" to isOnline,
            "lastSeen" to FieldValue.serverTimestamp(),
        )
        val publicPayload = mapOf(
            "uid" to uid,
            "displayName" to resolvedName.take(60),
            "isOnline" to isOnline,
            "lastSeen" to FieldValue.serverTimestamp(),
            "isDiscoverable" to true,
        )

        return try {
            val batch = db.batch()
            batch.set(privateRef, privatePayload, SetOptions.merge())
            batch.set(publicRef, publicPayload, SetOptions.merge())
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, privateRef.path)
            Result.failure(e)
        }
    }

    suspend fun setOnlineStatus(isOnline: Boolean): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.success(Unit)
        val privateRef = db.collection(USERS_COLLECTION).document(uid)
        val publicRef = db.collection(USER_DIRECTORY_COLLECTION).document(uid)
        return try {
            val privateExists = privateRef.get().await().exists()
            val publicExists = publicRef.get().await().exists()
            if (!privateExists || !publicExists) {
                return syncCurrentUserProfile(isOnline = isOnline)
            }
            val batch = db.batch()
            val updateFields = mapOf(
                "isOnline" to isOnline,
                "lastSeen" to FieldValue.serverTimestamp(),
            )
            batch.update(privateRef, updateFields)
            batch.update(publicRef, updateFields)
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, privateRef.path)
            Result.failure(e)
        }
    }

    suspend fun updateDisplayName(newName: String): Result<Unit> {
        val trimmed = newName.trim()
        require(trimmed.isNotEmpty() && trimmed.length <= 60) {
            "Display name must be 1 to 60 characters"
        }
        return syncCurrentUserProfile(isOnline = true, customDisplayName = trimmed)
    }

    fun observeOwnProfile(uid: String): Flow<UserProfile?> {
        val path = "$USERS_COLLECTION/$uid"
        return db.collection(USERS_COLLECTION).document(uid)
            .snapshots()
            .map { snapshot ->
                snapshot.toObject(
                    UserProfile::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            }
            .catch { error ->
                val firestoreError = error.unwrapFirestoreException()
                if (firestoreError == null && error is CancellationException) throw error
                if (auth.currentUser?.uid == uid) {
                    handleFirestoreError(firestoreError ?: error, OperationType.GET, path)
                }
                throw error
            }
    }

    fun observeDirectoryUsers(): Flow<List<DirectoryUser>> {
        val uid = requireUserId()
        return db.collection(USER_DIRECTORY_COLLECTION)
            .whereEqualTo("isDiscoverable", true)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    DirectoryUser::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).sortedWith(
                    compareByDescending<DirectoryUser> { it.isOnline }
                        .thenBy { it.displayName.lowercase() }
                )
            }
            .catch { error ->
                val firestoreError = error.unwrapFirestoreException()
                if (firestoreError == null && error is CancellationException) throw error
                if (auth.currentUser?.uid == uid) {
                    handleFirestoreError(
                        firestoreError ?: error,
                        OperationType.LIST,
                        USER_DIRECTORY_COLLECTION
                    )
                }
                throw error
            }
    }

    fun observeUserDirectoryEntry(userId: String): Flow<DirectoryUser?> {
        val currentUid = requireUserId()
        val path = "$USER_DIRECTORY_COLLECTION/$userId"
        return db.collection(USER_DIRECTORY_COLLECTION).document(userId)
            .snapshots()
            .map { snapshot ->
                snapshot.toObject(
                    DirectoryUser::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            }
            .catch { error ->
                val firestoreError = error.unwrapFirestoreException()
                if (firestoreError == null && error is CancellationException) throw error
                if (auth.currentUser?.uid == currentUid) {
                    handleFirestoreError(firestoreError ?: error, OperationType.GET, path)
                }
                throw error
            }
    }

    fun observeChats(currentUserId: String): Flow<List<ChatSummary>> {
        return db.collection(CHATS_COLLECTION)
            .whereArrayContains("participantIds", currentUserId)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    ChatSummary::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).sortedByDescending {
                    it.lastMessageAt ?: it.updatedAt ?: Timestamp(0, 0)
                }
            }
            .catch { error ->
                val firestoreError = error.unwrapFirestoreException()
                if (firestoreError == null && error is CancellationException) throw error
                if (auth.currentUser?.uid == currentUserId) {
                    handleFirestoreError(
                        firestoreError ?: error,
                        OperationType.LIST,
                        CHATS_COLLECTION
                    )
                }
                throw error
            }
    }

    suspend fun getChatSummary(chatId: String): ChatSummary? {
        val path = "$CHATS_COLLECTION/$chatId"
        return try {
            db.collection(CHATS_COLLECTION).document(chatId)
                .get()
                .await()
                .toObject(
                    ChatSummary::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            throw e
        }
    }

    suspend fun ensureChatRoom(
        partnerId: String,
        partnerName: String,
        currentUserDisplayName: String? = null,
    ): Result<String> {
        val currentUserId = requireUserId()
        require(partnerId.isNotBlank() && partnerId != currentUserId) {
            "Partner ID must be a distinct non-empty user ID"
        }
        val chatId = buildChatId(currentUserId, partnerId)
        val chatRef = db.collection(CHATS_COLLECTION).document(chatId)
        val myName = currentUserDisplayName?.trim()?.takeIf { it.isNotEmpty() }
            ?: auth.currentUser?.displayName?.trim()?.takeIf { it.isNotEmpty() }
            ?: auth.currentUser?.email?.substringBefore("@")?.takeIf { it.isNotBlank() }
            ?: "Me"
        val resolvedPartnerName = partnerName.trim().ifEmpty { "Mralios User" }
        val sortedIds = listOf(currentUserId, partnerId).sorted()

        return try {
            val snapshot = chatRef.get().await()
            if (!snapshot.exists()) {
                val payload = mapOf(
                    "participantIds" to sortedIds,
                    "participantNames" to mapOf(
                        currentUserId to myName.take(60),
                        partnerId to resolvedPartnerName.take(60),
                    ),
                    "lastMessage" to "",
                    "lastMessageType" to ChatSummary.TYPE_TEXT,
                    "lastSenderId" to "",
                    "lastMessageAt" to FieldValue.serverTimestamp(),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
                chatRef.set(payload).await()
            } else {
                val existingNames = (snapshot.get("participantNames") as? Map<*, *>)
                    ?.mapNotNull { (k, v) ->
                        val key = k as? String
                        val value = v as? String
                        if (key != null && value != null) key to value else null
                    }?.toMap().orEmpty()
                val updatedNames = existingNames + mapOf(
                    currentUserId to myName.take(60),
                    partnerId to resolvedPartnerName.take(60),
                )
                chatRef.update(
                    mapOf(
                        "participantNames" to updatedNames,
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            }
            Result.success(chatId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, chatRef.path)
            Result.failure(e)
        }
    }

    fun observeMessages(chatId: String, currentUserId: String): Flow<List<ChatMessage>> {
        val path = "$CHATS_COLLECTION/$chatId/$MESSAGES_COLLECTION"
        return db.collection(CHATS_COLLECTION)
            .document(chatId)
            .collection(MESSAGES_COLLECTION)
            .whereArrayContains("participantIds", currentUserId)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    ChatMessage::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).sortedBy { it.timestamp ?: Timestamp(Long.MAX_VALUE, 0) }
            }
            .catch { error ->
                val firestoreError = error.unwrapFirestoreException()
                if (firestoreError == null && error is CancellationException) throw error
                if (auth.currentUser?.uid == currentUserId) {
                    handleFirestoreError(firestoreError ?: error, OperationType.LIST, path)
                }
                throw error
            }
    }

    suspend fun sendMessage(
        partnerId: String,
        partnerName: String,
        rawText: String,
        senderDisplayName: String? = null,
        expiresAfterMs: Long = 0L,
    ): Result<String> {
        val currentUserId = requireUserId()
        val trimmedText = rawText.trim()
        if (trimmedText.isEmpty()) {
            return Result.failure(IllegalArgumentException("Cannot send an empty message"))
        }

        val resolvedSenderName = (senderDisplayName?.trim()?.takeIf { it.isNotEmpty() }
            ?: auth.currentUser?.displayName?.trim()?.takeIf { it.isNotEmpty() }
            ?: auth.currentUser?.email?.substringBefore("@")?.takeIf { it.isNotBlank() }
            ?: "Me").take(60)

        val chatIdResult = ensureChatRoom(
            partnerId = partnerId,
            partnerName = partnerName,
            currentUserDisplayName = resolvedSenderName
        )
        val chatId = chatIdResult.getOrElse { return Result.failure(it) }

        val encryptedText = CryptoUtils.encryptText(trimmedText.take(2000), chatId)
        val expiresAtMillis = if (expiresAfterMs > 0L) {
            System.currentTimeMillis() + expiresAfterMs
        } else {
            0L
        }

        val sortedIds = listOf(currentUserId, partnerId).sorted()
        val chatRef = db.collection(CHATS_COLLECTION).document(chatId)
        val messageRef = chatRef.collection(MESSAGES_COLLECTION).document()

        val messagePayload = mapOf(
            "senderId" to currentUserId,
            "senderName" to resolvedSenderName,
            "type" to ChatSummary.TYPE_TEXT,
            "text" to encryptedText.take(4000),
            "expiresAtMillis" to expiresAtMillis,
            "participantIds" to sortedIds,
            "timestamp" to FieldValue.serverTimestamp(),
        )
        val chatUpdatePayload = mapOf(
            "lastMessage" to encryptedText.take(4000),
            "lastMessageType" to ChatSummary.TYPE_TEXT,
            "lastSenderId" to currentUserId,
            "lastMessageAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp(),
        )

        return try {
            val batch = db.batch()
            batch.set(messageRef, messagePayload)
            batch.update(chatRef, chatUpdatePayload)
            batch.commit().await()
            Result.success(messageRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, messageRef.path)
            Result.failure(e)
        }
    }

    suspend fun sendVoiceMessage(
        partnerId: String,
        partnerName: String,
        encryptedAudioPayload: String,
        durationMs: Long,
        senderDisplayName: String? = null,
        expiresAfterMs: Long = 0L,
    ): Result<String> {
        val currentUserId = requireUserId()
        if (encryptedAudioPayload.isBlank()) {
            return Result.failure(IllegalArgumentException("Voice note payload is empty"))
        }

        val resolvedSenderName = (senderDisplayName?.trim()?.takeIf { it.isNotEmpty() }
            ?: auth.currentUser?.displayName?.trim()?.takeIf { it.isNotEmpty() }
            ?: auth.currentUser?.email?.substringBefore("@")?.takeIf { it.isNotBlank() }
            ?: "Me").take(60)

        val chatIdResult = ensureChatRoom(
            partnerId = partnerId,
            partnerName = partnerName,
            currentUserDisplayName = resolvedSenderName
        )
        val chatId = chatIdResult.getOrElse { return Result.failure(it) }
        val expiresAtMillis = if (expiresAfterMs > 0L) {
            System.currentTimeMillis() + expiresAfterMs
        } else {
            0L
        }

        val sortedIds = listOf(currentUserId, partnerId).sorted()
        val chatRef = db.collection(CHATS_COLLECTION).document(chatId)
        val messageRef = chatRef.collection(MESSAGES_COLLECTION).document()

        val messagePayload = mapOf(
            "senderId" to currentUserId,
            "senderName" to resolvedSenderName,
            "type" to ChatSummary.TYPE_AUDIO,
            "text" to "",
            "audioData" to encryptedAudioPayload,
            "durationMs" to durationMs.coerceIn(0L, 60_000L),
            "expiresAtMillis" to expiresAtMillis,
            "participantIds" to sortedIds,
            "timestamp" to FieldValue.serverTimestamp(),
        )
        val encryptedPreview = CryptoUtils.encryptText("[Voice Note]", chatId)
        val chatUpdatePayload = mapOf(
            "lastMessage" to encryptedPreview.take(4000),
            "lastMessageType" to ChatSummary.TYPE_AUDIO,
            "lastSenderId" to currentUserId,
            "lastMessageAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp(),
        )

        return try {
            val batch = db.batch()
            batch.set(messageRef, messagePayload)
            batch.update(chatRef, chatUpdatePayload)
            batch.commit().await()
            Result.success(messageRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, messageRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteExpiredMessage(chatId: String, messageId: String): Result<Unit> {
        val path = "$CHATS_COLLECTION/$chatId/$MESSAGES_COLLECTION/$messageId"
        return try {
            db.collection(CHATS_COLLECTION)
                .document(chatId)
                .collection(MESSAGES_COLLECTION)
                .document(messageId)
                .delete()
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    companion object {
        const val USERS_COLLECTION = "users"
        const val USER_DIRECTORY_COLLECTION = "user_directory"
        const val CHATS_COLLECTION = "chats"
        const val MESSAGES_COLLECTION = "messages"

        fun buildChatId(uidA: String, uidB: String): String {
            return listOf(uidA, uidB).sorted().joinToString("_")
        }
    }
}
