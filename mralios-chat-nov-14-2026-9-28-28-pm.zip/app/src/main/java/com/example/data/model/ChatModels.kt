package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.PropertyName
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val uid: String = "",
    val email: String = "",
    val displayName: String = "",
    @get:PropertyName("isOnline") @set:PropertyName("isOnline")
    var isOnline: Boolean = false,
    @ServerTimestamp val lastSeen: Timestamp? = null,
)

@IgnoreExtraProperties
data class DirectoryUser(
    @DocumentId val id: String = "",
    val uid: String = "",
    val displayName: String = "",
    @get:PropertyName("isOnline") @set:PropertyName("isOnline")
    var isOnline: Boolean = false,
    @ServerTimestamp val lastSeen: Timestamp? = null,
    @get:PropertyName("isDiscoverable") @set:PropertyName("isDiscoverable")
    var isDiscoverable: Boolean = true,
)

@IgnoreExtraProperties
data class ChatSummary(
    @DocumentId val id: String = "",
    val participantIds: List<String> = emptyList(),
    val participantNames: Map<String, String> = emptyMap(),
    val lastMessage: String = "",
    val lastMessageType: String = TYPE_TEXT,
    val lastSenderId: String = "",
    @ServerTimestamp val lastMessageAt: Timestamp? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
) {
    fun partnerId(currentUserId: String): String {
        return participantIds.firstOrNull { it != currentUserId } ?: currentUserId
    }

    fun partnerName(currentUserId: String): String {
        val partner = partnerId(currentUserId)
        return participantNames[partner]?.takeIf { it.isNotBlank() } ?: "Mralios User"
    }

    companion object {
        const val TYPE_TEXT = "text"
        const val TYPE_AUDIO = "audio"
    }
}

enum class DisappearingTimer(val durationMs: Long, val labelEn: String, val labelAr: String) {
    OFF(0L, "Off", "إيقاف"),
    TEN_SECONDS(10_000L, "10s", "10ث"),
    ONE_MINUTE(60_000L, "1m", "1د"),
    ONE_HOUR(3_600_000L, "1h", "1س"),
}

@IgnoreExtraProperties
data class ChatMessage(
    @DocumentId val id: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val type: String = ChatSummary.TYPE_TEXT,
    val text: String = "",
    val audioData: String = "",
    val durationMs: Long = 0L,
    val expiresAtMillis: Long = 0L,
    val participantIds: List<String> = emptyList(),
    @ServerTimestamp val timestamp: Timestamp? = null,
) {
    fun isAudio(): Boolean = type == ChatSummary.TYPE_AUDIO && audioData.isNotBlank()

    fun isExpired(nowMillis: Long = System.currentTimeMillis()): Boolean {
        return expiresAtMillis > 0L && nowMillis >= expiresAtMillis
    }
}
