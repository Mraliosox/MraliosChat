package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Chat
import androidx.compose.material.icons.rounded.AccessTime
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Email
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.localization.LocalAppStrings
import com.example.security.CryptoUtils
import com.example.ui.components.MraliosErrorState
import com.example.ui.components.UserAvatarBadge
import com.example.ui.components.formatLastSeen
import com.example.ui.theme.AccentRed
import com.example.ui.theme.AccentRedSoft
import com.example.ui.theme.BackgroundPrimary
import com.example.ui.theme.OfflineGray
import com.example.ui.theme.OnlineGreen
import com.example.ui.theme.OutlineSubtle
import com.example.ui.theme.SurfaceSecondary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.ProfileViewModel
import com.example.ui.viewmodel.UiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserProfileScreen(
    viewModel: ProfileViewModel,
    onNavigateBack: () -> Unit,
    onOpenChat: (partnerId: String, partnerName: String) -> Unit,
) {
    val strings = LocalAppStrings.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val isUpdatingName by viewModel.isUpdatingName.collectAsStateWithLifecycle()
    val updateMessage by viewModel.updateMessage.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    var showEditDialog by remember { mutableStateOf(false) }
    var draftName by remember { mutableStateOf("") }

    LaunchedEffect(updateMessage) {
        val msg = updateMessage
        if (msg != null) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearUpdateMessage()
        }
    }

    Scaffold(
        containerColor = BackgroundPrimary,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text(strings.profileTitle) },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("profile_back_button"),
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = strings.backContentDesc,
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = BackgroundPrimary,
                    titleContentColor = TextPrimary,
                    navigationIconContentColor = TextPrimary,
                ),
            )
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter,
        ) {
            when (val state = uiState) {
                is UiState.Loading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center,
                    ) {
                        CircularProgressIndicator(color = AccentRed)
                    }
                }

                is UiState.Error -> {
                    MraliosErrorState(message = state.message)
                }

                is UiState.Success -> {
                    val profile = state.data
                    val fingerprint = remember(profile.uid) {
                        CryptoUtils.safetyFingerprint(profile.uid)
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .widthIn(max = 560.dp)
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 24.dp, vertical = 16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        UserAvatarBadge(
                            displayName = profile.displayName,
                            isOnline = profile.isOnline,
                            size = 112.dp,
                            usePlaceholderArt = true,
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = profile.displayName,
                            style = MaterialTheme.typography.headlineMedium,
                            color = TextPrimary,
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = SurfaceSecondary,
                                modifier = Modifier.border(1.dp, OutlineSubtle, RoundedCornerShape(20.dp)),
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(9.dp)
                                            .clip(CircleShape)
                                            .background(if (profile.isOnline) OnlineGreen else OfflineGray)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (profile.isOnline) strings.onlineLabel else strings.offlineLabel,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = if (profile.isOnline) OnlineGreen else TextSecondary,
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = SurfaceSecondary,
                                modifier = Modifier.border(
                                    1.dp,
                                    AccentRed.copy(alpha = 0.4f),
                                    RoundedCornerShape(20.dp),
                                ),
                            ) {
                                Row(
                                    modifier = Modifier
                                        .background(AccentRedSoft)
                                        .padding(horizontal = 12.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.VerifiedUser,
                                        contentDescription = null,
                                        tint = AccentRed,
                                        modifier = Modifier.size(14.dp),
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = strings.verifiedEncryptedBadge,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextPrimary,
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = SurfaceSecondary,
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, OutlineSubtle, RoundedCornerShape(16.dp)),
                        ) {
                            Column(
                                modifier = Modifier.padding(18.dp),
                                verticalArrangement = Arrangement.spacedBy(16.dp),
                            ) {
                                ProfileDetailRow(
                                    icon = Icons.Rounded.AccessTime,
                                    label = strings.lastSeenLabel,
                                    value = if (profile.isOnline) {
                                        strings.onlineLabel
                                    } else {
                                        formatLastSeen(profile.lastSeenMillis, strings.justNow)
                                    },
                                )
                                if (profile.email != null) {
                                    ProfileDetailRow(
                                        icon = Icons.Rounded.Email,
                                        label = strings.emailInfoLabel,
                                        value = profile.email,
                                    )
                                }
                                ProfileDetailRow(
                                    icon = Icons.Rounded.Fingerprint,
                                    label = strings.fingerprintLabel,
                                    value = fingerprint,
                                    useMonospace = true,
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        if (profile.isOwnProfile) {
                            OutlinedButton(
                                onClick = {
                                    draftName = profile.displayName
                                    showEditDialog = true
                                },
                                enabled = !isUpdatingName,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                                    .testTag("edit_display_name_button"),
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Edit,
                                    contentDescription = null,
                                    tint = AccentRed,
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = strings.editDisplayNameButton,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.SemiBold,
                                )
                            }
                        } else {
                            Button(
                                onClick = { onOpenChat(profile.uid, profile.displayName) },
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = AccentRed),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                                    .testTag("profile_send_message_button"),
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Rounded.Chat,
                                    contentDescription = null,
                                    tint = TextPrimary,
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = strings.messageUserButton,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                )
                            }
                        }
                    }

                    if (showEditDialog) {
                        AlertDialog(
                            onDismissRequest = { showEditDialog = false },
                            containerColor = SurfaceSecondary,
                            titleContentColor = TextPrimary,
                            textContentColor = TextSecondary,
                            title = { Text(strings.editDisplayNameButton) },
                            text = {
                                OutlinedTextField(
                                    value = draftName,
                                    onValueChange = { draftName = it },
                                    label = { Text(strings.displayNameLabel) },
                                    singleLine = true,
                                    shape = RoundedCornerShape(14.dp),
                                    colors = mraliosTextFieldColors(),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("edit_display_name_input"),
                                )
                            },
                            confirmButton = {
                                Button(
                                    onClick = {
                                        viewModel.updateDisplayName(draftName)
                                        showEditDialog = false
                                    },
                                    enabled = draftName.trim().isNotEmpty(),
                                    colors = ButtonDefaults.buttonColors(containerColor = AccentRed),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.testTag("save_display_name_button"),
                                ) {
                                    Text(strings.saveNameButton)
                                }
                            },
                            dismissButton = {
                                TextButton(onClick = { showEditDialog = false }) {
                                    Text(strings.cancelButton, color = TextSecondary)
                                }
                            },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfileDetailRow(
    icon: ImageVector,
    label: String,
    value: String,
    useMonospace: Boolean = false,
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = AccentRed,
            modifier = Modifier.size(22.dp),
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
            )
            Text(
                text = value,
                style = if (useMonospace) {
                    MaterialTheme.typography.labelSmall
                } else {
                    MaterialTheme.typography.bodyLarge
                },
                color = TextPrimary,
            )
        }
    }
}
