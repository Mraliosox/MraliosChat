package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.RecordedVoiceClip
import com.example.data.firebase.unwrapFirestoreException
import com.example.data.model.ChatMessage
import com.example.data.model.DirectoryUser
import com.example.data.model.DisappearingTimer
import com.example.data.repository.ChatRepository
import com.example.security.CryptoUtils
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class PrivateChatViewModel(
    private val repository: ChatRepository,
    private val currentUserId: String,
    private val partnerId: String,
    private val initialPartnerName: String,
) : ViewModel() {

    val chatId: String = ChatRepository.buildChatId(currentUserId, partnerId)

    private val _messageInput = MutableStateFlow("")
    val messageInput: StateFlow<String> = _messageInput.asStateFlow()

    private val _isSending = MutableStateFlow(false)
    val isSending: StateFlow<Boolean> = _isSending.asStateFlow()

    private val _sendError = MutableStateFlow<String?>(null)
    val sendError: StateFlow<String?> = _sendError.asStateFlow()

    private val _selectedTimer = MutableStateFlow(DisappearingTimer.OFF)
    val selectedTimer: StateFlow<DisappearingTimer> = _selectedTimer.asStateFlow()

    private val _currentUserDisplayName = MutableStateFlow<String?>(null)
    private val deletedIdsAttempted = mutableSetOf<String>()

    private val tickerFlow = flow {
        while (true) {
            emit(System.currentTimeMillis())
            delay(1000L)
        }
    }

    val partnerProfile: StateFlow<DirectoryUser?> = repository
        .observeUserDirectoryEntry(partnerId)
        .catch { error ->
            val firestoreError = error.unwrapFirestoreException()
            if (firestoreError == null && error is CancellationException) throw error
            Log.w(TAG, "Error observing partner profile", firestoreError ?: error)
            emit(null)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = DirectoryUser(
                uid = partnerId,
                displayName = initialPartnerName,
                isOnline = false,
            ),
        )

    private val rawMessagesState: StateFlow<UiState<List<ChatMessage>>> = repository
        .observeMessages(chatId, currentUserId)
        .combine(MutableStateFlow(Unit)) { messages, _ ->
            val decrypted = messages.map { msg ->
                if (!msg.isAudio() && msg.text.isNotBlank()) {
                    msg.copy(text = CryptoUtils.decryptText(msg.text, chatId))
                } else {
                    msg
                }
            }
            UiState.Success(decrypted) as UiState<List<ChatMessage>>
        }
        .catch { error ->
            val firestoreError = error.unwrapFirestoreException()
            if (firestoreError == null && error is CancellationException) throw error
            val rootError = firestoreError ?: error
            Log.w(TAG, "Error observing chat messages", rootError)
            emit(UiState.Error(rootError.message ?: "Failed to load messages"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading,
        )

    val messagesState: StateFlow<UiState<List<ChatMessage>>> = combine(
        rawMessagesState,
        tickerFlow,
    ) { state, nowMs ->
        when (state) {
            is UiState.Loading -> UiState.Loading
            is UiState.Error -> state
            is UiState.Success -> {
                val expired = state.data.filter { it.isExpired(nowMs) }
                if (expired.isNotEmpty()) {
                    purgeExpiredMessages(expired)
                }
                UiState.Success(state.data.filterNot { it.isExpired(nowMs) })
            }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = UiState.Loading,
    )

    init {
        viewModelScope.launch {
            repository.observeOwnProfile(currentUserId)
                .catch { /* Ignore transient profile errors */ }
                .collect { profile ->
                    if (profile != null && profile.displayName.isNotBlank()) {
                        _currentUserDisplayName.value = profile.displayName
                    }
                }
        }
    }

    private fun purgeExpiredMessages(expired: List<ChatMessage>) {
        expired.forEach { msg ->
            if (msg.id.isNotBlank() && deletedIdsAttempted.add(msg.id)) {
                viewModelScope.launch {
                    val result = repository.deleteExpiredMessage(chatId, msg.id)
                    if (result.isFailure) {
                        deletedIdsAttempted.remove(msg.id)
                    }
                }
            }
        }
    }

    fun onMessageInputChanged(text: String) {
        _messageInput.value = text
    }

    fun onTimerSelected(timer: DisappearingTimer) {
        _selectedTimer.value = timer
    }

    fun clearSendError() {
        _sendError.value = null
    }

    fun showError(message: String) {
        _sendError.value = message
    }

    fun sendMessage() {
        val textToSend = _messageInput.value.trim()
        if (textToSend.isEmpty() || _isSending.value) return

        val resolvedPartnerName = partnerProfile.value?.displayName
            ?.takeIf { it.isNotBlank() } ?: initialPartnerName

        _isSending.value = true
        _sendError.value = null

        viewModelScope.launch {
            val result = repository.sendMessage(
                partnerId = partnerId,
                partnerName = resolvedPartnerName,
                rawText = textToSend,
                senderDisplayName = _currentUserDisplayName.value,
                expiresAfterMs = _selectedTimer.value.durationMs,
            )
            _isSending.value = false
            result.onSuccess {
                _messageInput.value = ""
            }.onFailure { error ->
                _sendError.value = error.localizedMessage ?: "Failed to send message"
            }
        }
    }

    fun sendVoiceClip(clip: RecordedVoiceClip) {
        if (_isSending.value) return
        val resolvedPartnerName = partnerProfile.value?.displayName
            ?.takeIf { it.isNotBlank() } ?: initialPartnerName

        _isSending.value = true
        _sendError.value = null

        viewModelScope.launch {
            val result = repository.sendVoiceMessage(
                partnerId = partnerId,
                partnerName = resolvedPartnerName,
                encryptedAudioPayload = clip.encryptedPayload,
                durationMs = clip.durationMs,
                senderDisplayName = _currentUserDisplayName.value,
                expiresAfterMs = _selectedTimer.value.durationMs,
            )
            _isSending.value = false
            result.onFailure { error ->
                _sendError.value = error.localizedMessage ?: "Failed to send voice note"
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
    }

    private companion object {
        const val TAG = "PrivateChatVM"
        const val STOP_TIMEOUT_MILLIS = 5000L
    }
}
