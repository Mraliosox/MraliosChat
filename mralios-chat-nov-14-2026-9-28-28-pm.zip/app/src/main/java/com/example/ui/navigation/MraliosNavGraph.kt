package com.example.ui.navigation

import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.R
import com.example.data.firebase.authStateFlow
import com.example.data.preferences.LanguagePreferences
import com.example.data.repository.ChatRepository
import com.example.ui.screens.ChatsScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.PrivateChatScreen
import com.example.ui.screens.RegisterScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.UserProfileScreen
import com.example.ui.screens.UsersScreen
import com.example.ui.viewmodel.ChatListViewModel
import com.example.ui.viewmodel.PrivateChatViewModel
import com.example.ui.viewmodel.ProfileViewModel
import com.example.ui.viewmodel.SettingsViewModel
import com.example.ui.viewmodel.UsersViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch

object Routes {
    const val SPLASH = "splash"
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val CHATS = "chats"
    const val USERS = "users"
    const val PRIVATE_CHAT = "private_chat/{partnerId}/{partnerName}"
    const val PROFILE = "profile/{userId}"
    const val SETTINGS = "settings"

    fun privateChat(partnerId: String, partnerName: String): String {
        return "private_chat/${Uri.encode(partnerId)}/${Uri.encode(partnerName)}"
    }

    fun profile(userId: String): String {
        return "profile/${Uri.encode(userId)}"
    }
}

@Composable
fun MraliosAppNavigation(
    languagePreferences: LanguagePreferences,
    onSplashFinished: () -> Unit = {},
) {
    val auth = Firebase.auth
    val currentUser by auth.authStateFlow()
        .collectAsStateWithLifecycle(initialValue = auth.currentUser)

    val navController = rememberNavController()
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    val appContext = context.applicationContext
    val databaseId = remember(appContext) {
        appContext.getString(R.string.firestore_database_id)
    }

    // Update online/offline presence while authenticated
    DisposableEffect(lifecycleOwner, currentUser?.uid) {
        val uid = currentUser?.uid
        val observer = LifecycleEventObserver { _, event ->
            if (uid != null) {
                val repo = ChatRepository(FirebaseFirestore.getInstance(databaseId), auth)
                when (event) {
                    Lifecycle.Event.ON_START -> {
                        scope.launch { repo.setOnlineStatus(true) }
                    }
                    Lifecycle.Event.ON_STOP -> {
                        scope.launch { repo.setOnlineStatus(false) }
                    }
                    else -> Unit
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    NavHost(
        navController = navController,
        startDestination = Routes.SPLASH,
    ) {
        composable(Routes.SPLASH) {
            SplashScreen(
                onNavigateToChats = {
                    onSplashFinished()
                    navController.navigate(Routes.CHATS) {
                        popUpTo(Routes.SPLASH) { inclusive = true }
                    }
                },
                onNavigateToLogin = {
                    onSplashFinished()
                    navController.navigate(Routes.LOGIN) {
                        popUpTo(Routes.SPLASH) { inclusive = true }
                    }
                },
            )
        }

        composable(Routes.LOGIN) {
            LoginScreen(
                onAuthSuccess = {
                    navController.navigate(Routes.CHATS) {
                        popUpTo(Routes.LOGIN) { inclusive = true }
                    }
                },
                onNavigateToRegister = {
                    navController.navigate(Routes.REGISTER)
                },
            )
        }

        composable(Routes.REGISTER) {
            RegisterScreen(
                onAuthSuccess = {
                    navController.navigate(Routes.CHATS) {
                        popUpTo(Routes.LOGIN) { inclusive = true }
                    }
                },
                onBackToLogin = {
                    navController.popBackStack()
                },
            )
        }

        composable(Routes.CHATS) {
            val user = currentUser
            if (user == null) {
                LaunchedEffect(Unit) {
                    navController.navigate(Routes.LOGIN) {
                        popUpTo(0) { inclusive = true }
                    }
                }
            } else {
                val uid = user.uid
                key(uid) {
                    val chatListViewModel: ChatListViewModel = viewModel(
                        key = "chats_$uid",
                        factory = viewModelFactory {
                            initializer {
                                val app = checkNotNull(this[APPLICATION_KEY])
                                val db = FirebaseFirestore.getInstance(
                                    app.getString(R.string.firestore_database_id)
                                )
                                ChatListViewModel(ChatRepository(db), uid)
                            }
                        },
                    )
                    ChatsScreen(
                        viewModel = chatListViewModel,
                        currentUserId = uid,
                        onOpenChat = { partnerId, partnerName ->
                            navController.navigate(Routes.privateChat(partnerId, partnerName))
                        },
                        onOpenUsers = {
                            navController.navigate(Routes.USERS)
                        },
                        onOpenProfile = {
                            navController.navigate(Routes.profile(uid))
                        },
                        onOpenSettings = {
                            navController.navigate(Routes.SETTINGS)
                        },
                    )
                }
            }
        }

        composable(Routes.USERS) {
            val user = currentUser
            if (user == null) {
                LaunchedEffect(Unit) {
                    navController.navigate(Routes.LOGIN) {
                        popUpTo(0) { inclusive = true }
                    }
                }
            } else {
                val uid = user.uid
                key(uid) {
                    val usersViewModel: UsersViewModel = viewModel(
                        key = "users_$uid",
                        factory = viewModelFactory {
                            initializer {
                                val app = checkNotNull(this[APPLICATION_KEY])
                                val db = FirebaseFirestore.getInstance(
                                    app.getString(R.string.firestore_database_id)
                                )
                                UsersViewModel(ChatRepository(db), uid)
                            }
                        },
                    )
                    UsersScreen(
                        viewModel = usersViewModel,
                        onNavigateBack = { navController.popBackStack() },
                        onOpenChat = { partnerId, partnerName ->
                            navController.navigate(Routes.privateChat(partnerId, partnerName))
                        },
                        onOpenProfile = { targetUserId ->
                            navController.navigate(Routes.profile(targetUserId))
                        },
                    )
                }
            }
        }

        composable(
            route = Routes.PRIVATE_CHAT,
            arguments = listOf(
                navArgument("partnerId") { type = NavType.StringType },
                navArgument("partnerName") { type = NavType.StringType },
            ),
        ) { backStackEntry ->
            val user = currentUser
            if (user == null) {
                LaunchedEffect(Unit) {
                    navController.navigate(Routes.LOGIN) {
                        popUpTo(0) { inclusive = true }
                    }
                }
            } else {
                val uid = user.uid
                val partnerId = backStackEntry.arguments?.getString("partnerId").orEmpty()
                val partnerName = backStackEntry.arguments?.getString("partnerName").orEmpty()
                key(uid, partnerId) {
                    val privateChatViewModel: PrivateChatViewModel = viewModel(
                        key = "chat_${uid}_$partnerId",
                        factory = viewModelFactory {
                            initializer {
                                val app = checkNotNull(this[APPLICATION_KEY])
                                val db = FirebaseFirestore.getInstance(
                                    app.getString(R.string.firestore_database_id)
                                )
                                PrivateChatViewModel(
                                    repository = ChatRepository(db),
                                    currentUserId = uid,
                                    partnerId = partnerId,
                                    initialPartnerName = partnerName,
                                )
                            }
                        },
                    )
                    PrivateChatScreen(
                        viewModel = privateChatViewModel,
                        currentUserId = uid,
                        partnerId = partnerId,
                        onNavigateBack = { navController.popBackStack() },
                        onOpenPartnerProfile = { targetId ->
                            navController.navigate(Routes.profile(targetId))
                        },
                    )
                }
            }
        }

        composable(
            route = Routes.PROFILE,
            arguments = listOf(
                navArgument("userId") { type = NavType.StringType },
            ),
        ) { backStackEntry ->
            val user = currentUser
            if (user == null) {
                LaunchedEffect(Unit) {
                    navController.navigate(Routes.LOGIN) {
                        popUpTo(0) { inclusive = true }
                    }
                }
            } else {
                val uid = user.uid
                val targetUserId = backStackEntry.arguments?.getString("userId").orEmpty()
                key(uid, targetUserId) {
                    val profileViewModel: ProfileViewModel = viewModel(
                        key = "profile_${uid}_$targetUserId",
                        factory = viewModelFactory {
                            initializer {
                                val app = checkNotNull(this[APPLICATION_KEY])
                                val db = FirebaseFirestore.getInstance(
                                    app.getString(R.string.firestore_database_id)
                                )
                                ProfileViewModel(
                                    repository = ChatRepository(db),
                                    currentUserId = uid,
                                    targetUserId = targetUserId,
                                )
                            }
                        },
                    )
                    UserProfileScreen(
                        viewModel = profileViewModel,
                        onNavigateBack = { navController.popBackStack() },
                        onOpenChat = { partnerId, partnerName ->
                            navController.navigate(Routes.privateChat(partnerId, partnerName))
                        },
                    )
                }
            }
        }

        composable(Routes.SETTINGS) {
            val user = currentUser
            if (user == null) {
                LaunchedEffect(Unit) {
                    navController.navigate(Routes.LOGIN) {
                        popUpTo(0) { inclusive = true }
                    }
                }
            } else {
                val uid = user.uid
                key(uid) {
                    val settingsViewModel: SettingsViewModel = viewModel(
                        key = "settings_$uid",
                        factory = viewModelFactory {
                            initializer {
                                val app = checkNotNull(this[APPLICATION_KEY])
                                val db = FirebaseFirestore.getInstance(
                                    app.getString(R.string.firestore_database_id)
                                )
                                SettingsViewModel(
                                    repository = ChatRepository(db),
                                    languagePreferences = languagePreferences,
                                )
                            }
                        },
                    )
                    SettingsScreen(
                        viewModel = settingsViewModel,
                        onNavigateBack = { navController.popBackStack() },
                        onOpenMyProfile = {
                            navController.navigate(Routes.profile(uid))
                        },
                        onSignedOut = {
                            navController.navigate(Routes.LOGIN) {
                                popUpTo(0) { inclusive = true }
                            }
                        },
                    )
                }
            }
        }
    }
}
