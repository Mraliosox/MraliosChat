package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val MraliosDarkColorScheme = darkColorScheme(
    primary = AccentRed,
    onPrimary = TextPrimary,
    primaryContainer = AccentRedDark,
    onPrimaryContainer = TextPrimary,
    secondary = SurfaceElevated,
    onSecondary = TextPrimary,
    secondaryContainer = SurfaceSecondary,
    onSecondaryContainer = TextSecondary,
    tertiary = AccentRedSoft,
    onTertiary = TextPrimary,
    background = BackgroundPrimary,
    onBackground = TextPrimary,
    surface = SurfaceSecondary,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = OutlineSubtle,
    error = ErrorRed,
    onError = BackgroundPrimary,
)

val MraliosShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(16.dp),
    extraLarge = RoundedCornerShape(20.dp),
)

@Composable
fun MraliosChatTheme(
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = MraliosDarkColorScheme,
        typography = MraliosTypography,
        shapes = MraliosShapes,
        content = content,
    )
}
