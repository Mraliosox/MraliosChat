package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.firebase.unwrapFirestoreException
import com.example.data.model.DirectoryUser
import com.example.data.model.UserProfile
import com.example.data.repository.ChatRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ProfileUiModel(
    val uid: String,
    val displayName: String,
    val email: String?,
    val isOnline: Boolean,
    val lastSeenMillis: Long?,
    val isOwnProfile: Boolean,
)

class ProfileViewModel(
    private val repository: ChatRepository,
    private val currentUserId: String,
    private val targetUserId: String,
) : ViewModel() {

    private val isOwn = currentUserId == targetUserId

    private val _isUpdatingName = MutableStateFlow(false)
    val isUpdatingName: StateFlow<Boolean> = _isUpdatingName.asStateFlow()

    private val _updateMessage = MutableStateFlow<String?>(null)
    val updateMessage: StateFlow<String?> = _updateMessage.asStateFlow()

    val uiState: StateFlow<UiState<ProfileUiModel>> = if (isOwn) {
        repository.observeOwnProfile(targetUserId)
            .combine(MutableStateFlow(Unit)) { profile: UserProfile?, _ ->
                if (profile == null) {
                    UiState.Error("Profile not found")
                } else {
                    UiState.Success(
                        ProfileUiModel(
                            uid = profile.uid.ifBlank { targetUserId },
                            displayName = profile.displayName.ifBlank { "Mralios User" },
                            email = profile.email.takeIf { it.isNotBlank() },
                            isOnline = profile.isOnline,
                            lastSeenMillis = profile.lastSeen?.toDate()?.time,
                            isOwnProfile = true,
                        )
                    )
                }
            }
            .catch { error ->
                val firestoreError = error.unwrapFirestoreException()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Error observing own profile", rootError)
                emit(UiState.Error(rootError.message ?: "Failed to load profile"))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Loading,
            )
    } else {
        repository.observeUserDirectoryEntry(targetUserId)
            .combine(MutableStateFlow(Unit)) { entry: DirectoryUser?, _ ->
                if (entry == null) {
                    UiState.Error("User profile not found")
                } else {
                    UiState.Success(
                        ProfileUiModel(
                            uid = entry.uid.ifBlank { targetUserId },
                            displayName = entry.displayName.ifBlank { "Mralios User" },
                            email = null,
                            isOnline = entry.isOnline,
                            lastSeenMillis = entry.lastSeen?.toDate()?.time,
                            isOwnProfile = false,
                        )
                    )
                }
            }
            .catch { error ->
                val firestoreError = error.unwrapFirestoreException()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Error observing user profile", rootError)
                emit(UiState.Error(rootError.message ?: "Failed to load profile"))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Loading,
            )
    }

    fun updateDisplayName(newName: String) {
        if (!isOwn || newName.isBlank()) return
        _isUpdatingName.value = true
        viewModelScope.launch {
            val result = repository.updateDisplayName(newName)
            _isUpdatingName.value = false
            _updateMessage.value = if (result.isSuccess) {
                "Display name updated"
            } else {
                result.exceptionOrNull()?.localizedMessage ?: "Update failed"
            }
        }
    }

    fun clearUpdateMessage() {
        _updateMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
    }

    private companion object {
        const val TAG = "ProfileVM"
        const val STOP_TIMEOUT_MILLIS = 5000L
    }
}
