package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BackgroundPrimary = Color(0xFF121212)
val SurfaceSecondary = Color(0xFF1E1E1E)
val SurfaceElevated = Color(0xFF27272A)
val AccentRed = Color(0xFFE53935)
val AccentRedDark = Color(0xFFB71C1C)
val AccentRedSoft = Color(0x29E53935)
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFBDBDBD)
val TextMuted = Color(0xFF8A8A8E)
val OutlineSubtle = Color(0xFF2E2E32)
val OnlineGreen = Color(0xFF4CAF50)
val OfflineGray = Color(0xFF757575)
val ErrorRed = Color(0xFFCF6679)
