package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Forum
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.audio.VoiceMessagingEngine
import com.example.audio.VoicePlaybackState
import com.example.data.model.ChatMessage
import com.example.data.model.DisappearingTimer
import com.example.localization.LocalAppStrings
import com.example.ui.components.MraliosEmptyState
import com.example.ui.components.MraliosErrorState
import com.example.ui.components.UserAvatarBadge
import com.example.ui.components.formatMessageTime
import com.example.ui.theme.AccentRed
import com.example.ui.theme.AccentRedSoft
import com.example.ui.theme.BackgroundPrimary
import com.example.ui.theme.OnlineGreen
import com.example.ui.theme.OutlineSubtle
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.SurfaceSecondary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.PrivateChatViewModel
import com.example.ui.viewmodel.UiState
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivateChatScreen(
    viewModel: PrivateChatViewModel,
    currentUserId: String,
    partnerId: String,
    onNavigateBack: () -> Unit,
    onOpenPartnerProfile: (String) -> Unit,
) {
    val strings = LocalAppStrings.current
    val isRtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val partnerProfile by viewModel.partnerProfile.collectAsStateWithLifecycle()
    val messagesState by viewModel.messagesState.collectAsStateWithLifecycle()
    val messageInput by viewModel.messageInput.collectAsStateWithLifecycle()
    val isSending by viewModel.isSending.collectAsStateWithLifecycle()
    val sendError by viewModel.sendError.collectAsStateWithLifecycle()
    val selectedTimer by viewModel.selectedTimer.collectAsStateWithLifecycle()

    val voiceEngine = remember(context, scope) { VoiceMessagingEngine(context, scope) }
    val isRecording by voiceEngine.isRecording.collectAsStateWithLifecycle()
    val recordingElapsedMs by voiceEngine.recordingElapsedMs.collectAsStateWithLifecycle()
    val playbackState by voiceEngine.playbackState.collectAsStateWithLifecycle()

    DisposableEffect(voiceEngine) {
        onDispose {
            voiceEngine.release()
        }
    }

    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasMicPermission = granted
        if (!granted) {
            viewModel.showError(strings.micPermissionDeniedError)
        }
    }

    var showTimerMenu by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }
    val listState = rememberLazyListState()

    val partnerName = partnerProfile?.displayName?.takeIf { it.isNotBlank() } ?: "Mralios User"
    val isPartnerOnline = partnerProfile?.isOnline ?: false

    LaunchedEffect(sendError) {
        val error = sendError
        if (error != null) {
            snackbarHostState.showSnackbar(error)
            viewModel.clearSendError()
        }
    }

    val messageCount = (messagesState as? UiState.Success)?.data?.size ?: 0
    LaunchedEffect(messageCount) {
        if (messageCount > 0) {
            listState.animateScrollToItem(messageCount - 1)
        }
    }

    Scaffold(
        containerColor = BackgroundPrimary,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("chat_back_button"),
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = strings.backContentDesc,
                        )
                    }
                },
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onOpenPartnerProfile(partnerId) }
                            .padding(vertical = 4.dp, horizontal = 4.dp)
                            .testTag("chat_header_profile_button"),
                    ) {
                        UserAvatarBadge(
                            displayName = partnerName,
                            isOnline = isPartnerOnline,
                            size = 40.dp,
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = partnerName,
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = if (isPartnerOnline) strings.onlineLabel else strings.offlineLabel,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isPartnerOnline) OnlineGreen else TextSecondary,
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(
                                    imageVector = Icons.Rounded.Lock,
                                    contentDescription = strings.e2eeBannerLabel,
                                    tint = AccentRed,
                                    modifier = Modifier.size(11.dp),
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "E2EE",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary,
                                )
                            }
                        }
                    }
                },
                actions = {
                    Box {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (selectedTimer != DisappearingTimer.OFF) {
                                AccentRedSoft
                            } else {
                                SurfaceElevated
                            },
                            modifier = Modifier
                                .padding(end = 8.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .border(
                                    1.dp,
                                    if (selectedTimer != DisappearingTimer.OFF) {
                                        AccentRed.copy(alpha = 0.55f)
                                    } else {
                                        OutlineSubtle
                                    },
                                    RoundedCornerShape(12.dp),
                                )
                                .clickable { showTimerMenu = true }
                                .testTag("disappearing_timer_button"),
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Timer,
                                    contentDescription = strings.disappearingTimerLabel,
                                    tint = if (selectedTimer != DisappearingTimer.OFF) {
                                        AccentRed
                                    } else {
                                        TextSecondary
                                    },
                                    modifier = Modifier.size(18.dp),
                                )
                                if (selectedTimer != DisappearingTimer.OFF) {
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (isRtl) selectedTimer.labelAr else selectedTimer.labelEn,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextPrimary,
                                        fontWeight = FontWeight.Bold,
                                    )
                                }
                            }
                        }

                        DropdownMenu(
                            expanded = showTimerMenu,
                            onDismissRequest = { showTimerMenu = false },
                            modifier = Modifier.background(SurfaceSecondary),
                        ) {
                            DisappearingTimer.entries.forEach { timer ->
                                val label = if (isRtl) timer.labelAr else timer.labelEn
                                DropdownMenuItem(
                                    text = {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Rounded.Timer,
                                                contentDescription = null,
                                                tint = if (timer == selectedTimer) AccentRed else TextSecondary,
                                                modifier = Modifier.size(18.dp),
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = "${strings.disappearingTimerLabel}: $label",
                                                color = if (timer == selectedTimer) TextPrimary else TextSecondary,
                                                fontWeight = if (timer == selectedTimer) FontWeight.Bold else FontWeight.Normal,
                                            )
                                        }
                                    },
                                    onClick = {
                                        viewModel.onTimerSelected(timer)
                                        showTimerMenu = false
                                    },
                                    modifier = Modifier.testTag("timer_option_${timer.name}"),
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SurfaceSecondary,
                    titleContentColor = TextPrimary,
                    navigationIconContentColor = TextPrimary,
                ),
            )
        },
        bottomBar = {
            Surface(
                color = SurfaceSecondary,
                tonalElevation = 4.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .imePadding(),
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    if (isRecording) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(AccentRedSoft)
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(AccentRed)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = strings.recordingLabel,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = AccentRed,
                                    fontWeight = FontWeight.Bold,
                                )
                            }
                            Text(
                                text = "${formatDurationMs(recordingElapsedMs)} / ${formatDurationMs(VoiceMessagingEngine.MAX_RECORDING_MS)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextPrimary,
                            )
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        OutlinedTextField(
                            value = messageInput,
                            onValueChange = viewModel::onMessageInputChanged,
                            placeholder = { Text(strings.typeMessageHint) },
                            maxLines = 4,
                            shape = RoundedCornerShape(16.dp),
                            colors = mraliosTextFieldColors(),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(
                                onSend = {
                                    if (messageInput.isNotBlank()) {
                                        viewModel.sendMessage()
                                    }
                                }
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("message_input_field"),
                        )
                        Spacer(modifier = Modifier.width(10.dp))

                        val hasText = messageInput.trim().isNotEmpty()
                        if (hasText || isSending) {
                            val canSend = hasText && !isSending
                            Box(
                                modifier = Modifier
                                    .size(50.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(if (canSend) AccentRed else SurfaceElevated),
                                contentAlignment = Alignment.Center,
                            ) {
                                IconButton(
                                    onClick = { viewModel.sendMessage() },
                                    enabled = canSend,
                                    modifier = Modifier.testTag("send_message_button"),
                                ) {
                                    if (isSending) {
                                        CircularProgressIndicator(
                                            color = TextPrimary,
                                            strokeWidth = 2.dp,
                                            modifier = Modifier.size(20.dp),
                                        )
                                    } else {
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Rounded.Send,
                                            contentDescription = strings.sendContentDesc,
                                            tint = if (canSend) TextPrimary else TextSecondary,
                                        )
                                    }
                                }
                            }
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(50.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(if (isRecording) AccentRed else SurfaceElevated)
                                    .border(
                                        1.dp,
                                        if (isRecording) AccentRed else OutlineSubtle,
                                        RoundedCornerShape(14.dp),
                                    )
                                    .semantics {
                                        contentDescription = strings.micHoldHint
                                    }
                                    .pointerInput(hasMicPermission, viewModel.chatId) {
                                        detectTapGestures(
                                            onPress = {
                                                if (!hasMicPermission) {
                                                    micPermissionLauncher.launch(
                                                        Manifest.permission.RECORD_AUDIO
                                                    )
                                                    return@detectTapGestures
                                                }
                                                val started = voiceEngine.startRecording(
                                                    onMaxDurationReached = {
                                                        val clip = voiceEngine.stopAndEncryptRecording(
                                                            viewModel.chatId
                                                        )
                                                        if (clip != null) {
                                                            viewModel.sendVoiceClip(clip)
                                                        }
                                                    }
                                                )
                                                if (!started) {
                                                    viewModel.showError(strings.micPermissionDeniedError)
                                                    return@detectTapGestures
                                                }
                                                val released = tryAwaitRelease()
                                                if (voiceEngine.isRecording.value) {
                                                    if (released) {
                                                        val clip = voiceEngine.stopAndEncryptRecording(
                                                            viewModel.chatId
                                                        )
                                                        if (clip != null) {
                                                            viewModel.sendVoiceClip(clip)
                                                        } else {
                                                            viewModel.showError(strings.voiceTooShortError)
                                                        }
                                                    } else {
                                                        voiceEngine.cancelRecording()
                                                    }
                                                }
                                            }
                                        )
                                    }
                                    .testTag("voice_record_button"),
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Mic,
                                    contentDescription = strings.micHoldHint,
                                    tint = if (isRecording) TextPrimary else AccentRed,
                                )
                            }
                        }
                    }
                }
            }
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter,
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 720.dp),
            ) {
                when (val state = messagesState) {
                    is UiState.Loading -> {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center,
                        ) {
                            CircularProgressIndicator(color = AccentRed)
                        }
                    }

                    is UiState.Error -> {
                        MraliosErrorState(message = state.message)
                    }

                    is UiState.Success -> {
                        if (state.data.isEmpty()) {
                            MraliosEmptyState(
                                icon = Icons.Rounded.Forum,
                                title = strings.emptyChatTitle,
                                subtitle = strings.emptyChatSubtitle,
                            )
                        } else {
                            LazyColumn(
                                state = listState,
                                contentPadding = PaddingValues(
                                    horizontal = 14.dp,
                                    vertical = 12.dp,
                                ),
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxSize(),
                            ) {
                                items(state.data, key = { it.id }) { msg ->
                                    MessageBubbleRow(
                                        message = msg,
                                        isMine = msg.senderId == currentUserId,
                                        justNowLabel = strings.justNow,
                                        playbackState = playbackState,
                                        onToggleVoicePlay = {
                                            voiceEngine.togglePlayback(
                                                messageId = msg.id,
                                                encryptedAudioPayload = msg.audioData,
                                                chatId = viewModel.chatId,
                                                fallbackDurationMs = msg.durationMs,
                                                onError = viewModel::showError,
                                            )
                                        },
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MessageBubbleRow(
    message: ChatMessage,
    isMine: Boolean,
    justNowLabel: String,
    playbackState: VoicePlaybackState,
    onToggleVoicePlay: () -> Unit,
) {
    val strings = LocalAppStrings.current
    val bubbleShape = if (isMine) {
        RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 4.dp)
    } else {
        RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = 4.dp, bottomEnd = 16.dp)
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isMine) Arrangement.End else Arrangement.Start,
    ) {
        Surface(
            shape = bubbleShape,
            color = if (isMine) AccentRed else SurfaceSecondary,
            modifier = Modifier
                .widthIn(max = 300.dp)
                .then(
                    if (!isMine) {
                        Modifier.border(1.dp, OutlineSubtle, bubbleShape)
                    } else {
                        Modifier
                    }
                )
                .testTag("message_bubble_${message.id}"),
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            ) {
                Text(
                    text = message.senderName.ifBlank { "User" },
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = if (isMine) TextPrimary.copy(alpha = 0.85f) else AccentRed,
                )
                Spacer(modifier = Modifier.height(4.dp))

                if (message.isAudio()) {
                    val isActiveTrack = playbackState.playingMessageId == message.id
                    val isPlayingThis = isActiveTrack && playbackState.isPlaying
                    val isBufferingThis = isActiveTrack && playbackState.isBuffering
                    val displayProgress = if (isActiveTrack) playbackState.progress else 0f
                    val displayTimeMs = if (isActiveTrack && playbackState.positionMs > 0L) {
                        playbackState.positionMs
                    } else {
                        message.durationMs
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.widthIn(min = 190.dp),
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isMine) BackgroundPrimary.copy(alpha = 0.28f) else AccentRedSoft
                                ),
                            contentAlignment = Alignment.Center,
                        ) {
                            IconButton(
                                onClick = onToggleVoicePlay,
                                modifier = Modifier.testTag("voice_play_button_${message.id}"),
                            ) {
                                if (isBufferingThis) {
                                    CircularProgressIndicator(
                                        color = TextPrimary,
                                        strokeWidth = 2.dp,
                                        modifier = Modifier.size(18.dp),
                                    )
                                } else {
                                    Icon(
                                        imageVector = if (isPlayingThis) {
                                            Icons.Rounded.Pause
                                        } else {
                                            Icons.Rounded.PlayArrow
                                        },
                                        contentDescription = if (isPlayingThis) {
                                            strings.pauseContentDesc
                                        } else {
                                            strings.playContentDesc
                                        },
                                        tint = if (isMine) TextPrimary else AccentRed,
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            LinearProgressIndicator(
                                progress = { displayProgress },
                                color = if (isMine) TextPrimary else AccentRed,
                                trackColor = if (isMine) {
                                    TextPrimary.copy(alpha = 0.25f)
                                } else {
                                    OutlineSubtle
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(4.dp)
                                    .clip(RoundedCornerShape(2.dp)),
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = formatDurationMs(displayTimeMs),
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isMine) TextPrimary.copy(alpha = 0.85f) else TextSecondary,
                            )
                        }
                    }
                } else {
                    Text(
                        text = message.text,
                        style = MaterialTheme.typography.bodyLarge,
                        color = TextPrimary,
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.align(Alignment.End),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (message.expiresAtMillis > 0L) {
                        val remainingSec = ((message.expiresAtMillis - System.currentTimeMillis()) / 1000L)
                            .coerceAtLeast(0L)
                        Icon(
                            imageVector = Icons.Rounded.Timer,
                            contentDescription = strings.disappearingTimerLabel,
                            tint = if (isMine) TextPrimary.copy(alpha = 0.82f) else AccentRed,
                            modifier = Modifier.size(12.dp),
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = formatRemainingSeconds(remainingSec),
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isMine) TextPrimary.copy(alpha = 0.82f) else AccentRed,
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    Text(
                        text = formatMessageTime(message.timestamp, justNowLabel),
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isMine) TextPrimary.copy(alpha = 0.78f) else TextSecondary,
                    )
                }
            }
        }
    }
}

private fun formatDurationMs(durationMs: Long): String {
    val totalSeconds = (durationMs / 1000L).coerceAtLeast(0L)
    val minutes = totalSeconds / 60L
    val seconds = totalSeconds % 60L
    return String.format(Locale.US, "%02d:%02d", minutes, seconds)
}

private fun formatRemainingSeconds(seconds: Long): String {
    return when {
        seconds >= 3600L -> "${seconds / 3600L}h"
        seconds >= 60L -> "${seconds / 60L}m"
        else -> "${seconds}s"
    }
}
