package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.preferences.AppLanguage
import com.example.data.preferences.LanguagePreferences
import com.example.data.repository.ChatRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val repository: ChatRepository,
    private val languagePreferences: LanguagePreferences,
) : ViewModel() {

    val currentLanguage: StateFlow<AppLanguage> = languagePreferences.languageFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = AppLanguage.ENGLISH,
        )

    val biometricLockEnabled: StateFlow<Boolean> = languagePreferences.biometricLockFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = true,
        )

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch {
            languagePreferences.setLanguage(language)
        }
    }

    fun setBiometricLockEnabled(enabled: Boolean) {
        viewModelScope.launch {
            languagePreferences.setBiometricLockEnabled(enabled)
        }
    }

    suspend fun markOfflineBeforeSignOut() {
        repository.setOnlineStatus(isOnline = false)
    }

    override fun onCleared() {
        super.onCleared()
    }
}
