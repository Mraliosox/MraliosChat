package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.firebase.unwrapFirestoreException
import com.example.data.model.ChatSummary
import com.example.data.repository.ChatRepository
import com.example.security.CryptoUtils
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ChatListViewModel(
    private val repository: ChatRepository,
    private val currentUserId: String,
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    init {
        viewModelScope.launch {
            repository.syncCurrentUserProfile(isOnline = true)
        }
    }

    private val allChatsState: StateFlow<UiState<List<ChatSummary>>> = repository
        .observeChats(currentUserId)
        .map<List<ChatSummary>, UiState<List<ChatSummary>>> { chats ->
            val decrypted = chats.map { chat ->
                if (chat.lastMessage.isNotBlank()) {
                    chat.copy(lastMessage = CryptoUtils.decryptText(chat.lastMessage, chat.id))
                } else {
                    chat
                }
            }
            UiState.Success(decrypted)
        }
        .catch { error ->
            val firestoreError = error.unwrapFirestoreException()
            if (firestoreError == null && error is CancellationException) throw error
            val rootError = firestoreError ?: error
            Log.w(TAG, "Error observing chats", rootError)
            emit(UiState.Error(rootError.message ?: "Failed to load conversations"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading,
        )

    val uiState: StateFlow<UiState<List<ChatSummary>>> = combine(
        allChatsState,
        _searchQuery
    ) { state, query ->
        when (state) {
            is UiState.Loading -> UiState.Loading
            is UiState.Error -> state
            is UiState.Success -> {
                val trimmed = query.trim().lowercase()
                val filtered = if (trimmed.isEmpty()) {
                    state.data
                } else {
                    state.data.filter { chat ->
                        chat.partnerName(currentUserId).lowercase().contains(trimmed) ||
                            chat.lastMessage.lowercase().contains(trimmed)
                    }
                }
                UiState.Success(filtered)
            }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = UiState.Loading,
    )

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    override fun onCleared() {
        super.onCleared()
    }

    private companion object {
        const val TAG = "ChatListVM"
        const val STOP_TIMEOUT_MILLIS = 5000L
    }
}
