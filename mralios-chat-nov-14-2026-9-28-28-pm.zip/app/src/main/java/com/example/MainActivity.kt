package com.example

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.firebase.authStateFlow
import com.example.data.preferences.AppLanguage
import com.example.data.preferences.LanguagePreferences
import com.example.localization.LocalAppStrings
import com.example.localization.stringsFor
import com.example.security.BiometricLockHelper
import com.example.ui.navigation.MraliosAppNavigation
import com.example.ui.theme.AccentRed
import com.example.ui.theme.AccentRedSoft
import com.example.ui.theme.BackgroundPrimary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.MraliosChatTheme
import com.example.ui.theme.OutlineSubtle
import com.example.ui.theme.SurfaceSecondary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.google.firebase.Firebase
import com.google.firebase.auth.auth

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Anti-Spy & Screen Protection: block screenshots, screen recording, and recents preview
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE,
        )
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        setContent {
            val languagePreferences = remember(applicationContext) {
                LanguagePreferences(applicationContext)
            }
            val currentLanguage by languagePreferences.languageFlow
                .collectAsStateWithLifecycle(initialValue = AppLanguage.ENGLISH)
            val biometricLockEnabled by languagePreferences.biometricLockFlow
                .collectAsStateWithLifecycle(initialValue = true)
            val currentUser by Firebase.auth.authStateFlow()
                .collectAsStateWithLifecycle(initialValue = Firebase.auth.currentUser)

            var hasPassedSplash by remember { mutableStateOf(false) }
            var isAppLocked by remember { mutableStateOf(Firebase.auth.currentUser != null) }
            var promptedForCurrentLock by remember { mutableStateOf(false) }
            var lockError by remember { mutableStateOf<String?>(null) }

            val lifecycleOwner = LocalLifecycleOwner.current
            DisposableEffect(lifecycleOwner, biometricLockEnabled, currentUser?.uid) {
                val observer = LifecycleEventObserver { _, event ->
                    when (event) {
                        Lifecycle.Event.ON_STOP -> {
                            if (biometricLockEnabled && currentUser != null && hasPassedSplash) {
                                isAppLocked = true
                                promptedForCurrentLock = false
                            }
                        }
                        else -> Unit
                    }
                }
                lifecycleOwner.lifecycle.addObserver(observer)
                onDispose {
                    lifecycleOwner.lifecycle.removeObserver(observer)
                }
            }

            LaunchedEffect(currentUser?.uid, biometricLockEnabled) {
                if (currentUser == null || !biometricLockEnabled) {
                    isAppLocked = false
                    promptedForCurrentLock = false
                    lockError = null
                }
            }

            val layoutDirection = if (currentLanguage.isRtl) {
                LayoutDirection.Rtl
            } else {
                LayoutDirection.Ltr
            }
            val strings = remember(currentLanguage) { stringsFor(currentLanguage) }

            val triggerUnlock = remember(strings) {
                {
                    lockError = null
                    BiometricLockHelper.authenticate(
                        activity = this@MainActivity,
                        title = strings.biometricPromptTitle,
                        subtitle = strings.biometricPromptSubtitle,
                        onSuccess = {
                            isAppLocked = false
                            promptedForCurrentLock = false
                            lockError = null
                        },
                        onError = { error ->
                            lockError = error
                        },
                    )
                }
            }

            val showLockGate = hasPassedSplash &&
                biometricLockEnabled &&
                currentUser != null &&
                isAppLocked

            LaunchedEffect(showLockGate) {
                if (showLockGate && !promptedForCurrentLock) {
                    promptedForCurrentLock = true
                    triggerUnlock()
                }
            }

            CompositionLocalProvider(
                LocalLayoutDirection provides layoutDirection,
                LocalAppStrings provides strings,
            ) {
                MraliosChatTheme {
                    Box(modifier = Modifier.fillMaxSize()) {
                        MraliosAppNavigation(
                            languagePreferences = languagePreferences,
                            onSplashFinished = { hasPassedSplash = true },
                        )
                        if (showLockGate) {
                            BiometricLockOverlay(
                                errorMessage = lockError,
                                onUnlockClick = triggerUnlock,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BiometricLockOverlay(
    errorMessage: String?,
    onUnlockClick: () -> Unit,
) {
    val strings = LocalAppStrings.current
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundPrimary)
            .systemBarsPadding()
            .padding(24.dp)
            .testTag("biometric_lock_overlay"),
        contentAlignment = Alignment.Center,
    ) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = SurfaceSecondary,
            modifier = Modifier
                .widthIn(max = 420.dp)
                .border(1.dp, OutlineSubtle, RoundedCornerShape(20.dp)),
        ) {
            Column(
                modifier = Modifier.padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Box(
                    modifier = Modifier
                        .size(76.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(AccentRedSoft)
                        .border(1.dp, AccentRed.copy(alpha = 0.45f), RoundedCornerShape(22.dp)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Shield,
                        contentDescription = strings.appLockedTitle,
                        tint = AccentRed,
                        modifier = Modifier.size(40.dp),
                    )
                }
                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = strings.appLockedTitle,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    textAlign = TextAlign.Center,
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = strings.appLockedSubtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    textAlign = TextAlign.Center,
                )
                if (!errorMessage.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = errorMessage,
                        style = MaterialTheme.typography.bodySmall,
                        color = ErrorRed,
                        textAlign = TextAlign.Center,
                    )
                }
                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = onUnlockClick,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AccentRed),
                    modifier = Modifier
                        .height(50.dp)
                        .testTag("unlock_app_button"),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Lock,
                        contentDescription = null,
                        tint = TextPrimary,
                        modifier = Modifier.size(18.dp),
                    )
                    Spacer(modifier = Modifier.size(8.dp))
                    Text(
                        text = strings.unlockButton,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
    }
}
