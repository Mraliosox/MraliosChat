package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.security.CryptoUtils
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Mralios.Chat", appName)
  }

  @Test
  fun `encryptText uses random IV and decrypts English and Arabic cleanly`() {
    val chatId = "alice_bob"
    val plain = "Hello Mralios — مرحباً بك في التشفير"
    val cipher1 = CryptoUtils.encryptText(plain, chatId)
    val cipher2 = CryptoUtils.encryptText(plain, chatId)

    assertTrue(cipher1.startsWith("E2E1:"))
    assertTrue(cipher2.startsWith("E2E1:"))
    assertNotEquals(cipher1, cipher2)
    assertEquals(plain, CryptoUtils.decryptText(cipher1, chatId))
    assertEquals(plain, CryptoUtils.decryptText(cipher2, chatId))
  }

  @Test
  fun `encryptBytes and decryptBytes roundtrip binary voice payload`() {
    val chatId = "alice_bob"
    val bytes = ByteArray(256) { it.toByte() }
    val encrypted = CryptoUtils.encryptBytes(bytes, chatId)
    val decrypted = CryptoUtils.decryptBytes(encrypted, chatId)

    assertNotNull(decrypted)
    assertArrayEquals(bytes, decrypted)
  }
}
