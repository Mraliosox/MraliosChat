package com.example

import com.example.data.preferences.AppLanguage
import com.example.data.repository.ChatRepository
import com.example.localization.stringsFor
import com.example.security.CryptoUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun buildChatId_isDeterministicRegardlessOfOrder() {
        val ab = ChatRepository.buildChatId("userA", "userB")
        val ba = ChatRepository.buildChatId("userB", "userA")
        assertEquals("userA_userB", ab)
        assertEquals(ab, ba)
    }

    @Test
    fun languageToggle_switchesRtlAndLocalizedStrings() {
        assertFalse(AppLanguage.ENGLISH.isRtl)
        assertTrue(AppLanguage.ARABIC.isRtl)
        assertEquals("Chats", stringsFor(AppLanguage.ENGLISH).chatsTitle)
        assertEquals("المحادثات", stringsFor(AppLanguage.ARABIC).chatsTitle)
    }

    @Test
    fun safetyFingerprint_isDeterministicAndUniquePerUser() {
        val fpA1 = CryptoUtils.safetyFingerprint("uid_alice")
        val fpA2 = CryptoUtils.safetyFingerprint("uid_alice")
        val fpB = CryptoUtils.safetyFingerprint("uid_bob")
        assertEquals(fpA1, fpA2)
        assertNotEquals(fpA1, fpB)
        assertEquals(8, fpA1.split(" ").size)
    }
}
