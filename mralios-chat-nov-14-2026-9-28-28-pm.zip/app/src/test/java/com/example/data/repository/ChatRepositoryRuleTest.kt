package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.util.UUID

class ChatRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun syncProfile_andObserveDirectory_succeedsForSignedInUsers() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val aliceRepo = ChatRepository(firestore, auth)

        val syncResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.syncCurrentUserProfile(isOnline = true, customDisplayName = "Alice")
        }
        assertTrue(syncResult.isSuccess)

        val directory = withTimeout(FLOW_TIMEOUT_MS) {
            aliceRepo.observeDirectoryUsers().first { list -> list.any { it.uid == aliceUid } }
        }
        val aliceEntry = directory.first { it.uid == aliceUid }
        assertEquals("Alice", aliceEntry.displayName)
        assertTrue(aliceEntry.isOnline)
    }

    @Test
    fun sendMessage_betweenTwoUsers_isReadableByBothParticipants() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val aliceRepo = ChatRepository(firestore, auth)
        val syncResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.syncCurrentUserProfile(isOnline = true, customDisplayName = "Alice")
        }
        assertTrue("Alice sync failed: ${syncResult.exceptionOrNull()}", syncResult.isSuccess)

        val bobUid = signInTestUser(BOB_EMAIL)
        val bobRepo = ChatRepository(firestore, auth)
        val bobSync = withTimeout(DEFAULT_TIMEOUT_MS) {
            bobRepo.syncCurrentUserProfile(isOnline = true, customDisplayName = "Bob")
        }
        assertTrue("Bob sync failed: ${bobSync.exceptionOrNull()}", bobSync.isSuccess)

        val uniqueText = "Hello Alice ${UUID.randomUUID()}"
        val sendResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            bobRepo.sendMessage(
                partnerId = aliceUid,
                partnerName = "Alice",
                rawText = uniqueText,
                senderDisplayName = "Bob"
            )
        }
        assertTrue("sendMessage failed: ${sendResult.exceptionOrNull()}", sendResult.isSuccess)

        signInTestUser(ALICE_EMAIL)
        val chatId = ChatRepository.buildChatId(aliceUid, bobUid)
        val messages = withTimeout(FLOW_TIMEOUT_MS) {
            aliceRepo.observeMessages(chatId, aliceUid).first { list ->
                list.any { com.example.security.CryptoUtils.decryptText(it.text, chatId) == uniqueText }
            }
        }
        val matchingMsg = messages.first {
            com.example.security.CryptoUtils.decryptText(it.text, chatId) == uniqueText
        }
        assertEquals(bobUid, matchingMsg.senderId)
        assertTrue("Expected E2EE ciphertext prefix in Firestore", matchingMsg.text.startsWith("E2E1:"))
    }

    @Test
    fun sendVoiceMessage_betweenTwoUsers_storesEncryptedAudioAndDeletesWhenExpired() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val bobUid = signInTestUser(BOB_EMAIL)
        val bobRepo = ChatRepository(firestore, auth)
        val chatId = ChatRepository.buildChatId(aliceUid, bobUid)

        val rawAudioBytes = ByteArray(64) { index -> (index * 3).toByte() }
        val encryptedPayload = com.example.security.CryptoUtils.encryptBytes(rawAudioBytes, chatId)

        val voiceResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            bobRepo.sendVoiceMessage(
                partnerId = aliceUid,
                partnerName = "Alice",
                encryptedAudioPayload = encryptedPayload,
                durationMs = 2400L,
                senderDisplayName = "Bob",
                expiresAfterMs = 0L,
            )
        }
        assertTrue("sendVoiceMessage failed: ${voiceResult.exceptionOrNull()}", voiceResult.isSuccess)

        val messages = withTimeout(FLOW_TIMEOUT_MS) {
            bobRepo.observeMessages(chatId, bobUid).first { list ->
                list.any { it.isAudio() }
            }
        }
        val audioMsg = messages.first { it.isAudio() }
        assertEquals(2400L, audioMsg.durationMs)
        val decryptedBytes = com.example.security.CryptoUtils.decryptBytes(audioMsg.audioData, chatId)
        assertNotNull(decryptedBytes)
        assertTrue(rawAudioBytes.contentEquals(decryptedBytes))
    }

    @Test
    fun sendMessage_emptyText_isBlocked() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val bobUid = signInTestUser(BOB_EMAIL)
        val bobRepo = ChatRepository(firestore, auth)

        val emptyResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            bobRepo.sendMessage(
                partnerId = aliceUid,
                partnerName = "Alice",
                rawText = "   ",
                senderDisplayName = "Bob"
            )
        }
        assertTrue(emptyResult.isFailure)
        assertEquals(ChatRepository.buildChatId(aliceUid, bobUid), ChatRepository.buildChatId(bobUid, aliceUid))
    }

    @Test
    fun observeChats_nonParticipant_cannotReadOtherUsersChat() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val bobUid = signInTestUser(BOB_EMAIL)
        val bobRepo = ChatRepository(firestore, auth)
        withTimeout(DEFAULT_TIMEOUT_MS) {
            bobRepo.sendMessage(
                partnerId = aliceUid,
                partnerName = "Alice",
                rawText = "Private note ${UUID.randomUUID()}",
                senderDisplayName = "Bob"
            )
        }

        val charlieUid = signInTestUser(CHARLIE_EMAIL)
        val charlieRepo = ChatRepository(firestore, auth)
        val chatId = ChatRepository.buildChatId(aliceUid, bobUid)

        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                charlieRepo.getChatSummary(chatId)
            }
            fail("Expected PERMISSION_DENIED for non-participant Charlie")
        } catch (e: Exception) {
            val firestoreException = e.unwrapFirestoreException()
            assertNotNull("Expected FirebaseFirestoreException, got $e", firestoreException)
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreException?.code)
        }

        val charlieChats = withTimeout(FLOW_TIMEOUT_MS) {
            charlieRepo.observeChats(charlieUid).first()
        }
        assertTrue(charlieChats.none { it.id == chatId })
    }

    @Test
    fun observeDirectoryUsers_unauthenticated_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val repo = ChatRepository(firestore, auth)
        auth.signOut()

        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repo.observeChats(aliceUid).first()
            }
            fail("Expected PERMISSION_DENIED when unauthenticated")
        } catch (e: Exception) {
            val firestoreException = e.unwrapFirestoreException()
            assertNotNull("Expected nested FirebaseFirestoreException, got $e", firestoreException)
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreException?.code)
        }
    }

    private companion object {
        const val ALICE_EMAIL = "alice_rule_test@mralios.chat"
        const val BOB_EMAIL = "bob_rule_test@mralios.chat"
        const val CHARLIE_EMAIL = "charlie_rule_test@mralios.chat"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 3000L
    }
}
