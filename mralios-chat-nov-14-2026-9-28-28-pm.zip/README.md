# Mralios.Chat

A hardened, dark-first native Android chat application built with **Kotlin**, **Jetpack Compose**, **Material Design 3**, **Firebase Authentication (Credential Manager Google Sign-In)**, and **Cloud Firestore**.

---

## Security & Privacy Architecture

- **End-to-End Encryption (AES-256-GCM)**:
  - Implemented in `app/src/main/java/com/example/security/CryptoUtils.kt`.
  - Every text message and voice note payload is encrypted client-side with **AES/GCM/NoPadding** using a fresh **96-bit random Initialization Vector (IV)** per message, ensuring identical plaintexts never produce identical ciphertexts.
  - Encryption verification fingerprints are displayed on every user's Profile screen.
- **Anti-Spy Screen Protection**:
  - `MainActivity` enforces `WindowManager.LayoutParams.FLAG_SECURE` to block screenshots, screen recording, and recent-apps preview thumbnails.
- **Biometric / Device Credential App Lock**:
  - Uses `androidx.biometric:biometric` (`BiometricLockHelper.kt`) supporting Fingerprint, Face, and Device PIN/Pattern/Password upon launch and app resume (toggleable in **Settings -> Security & Privacy**).
- **Disappearing / Self-Destructing Messages**:
  - Per-chat timer (`Off`, `10s`, `1m`, `1h`) attaches `expiresAtMillis` to messages. Expired messages are hidden immediately and purged from Firestore, enforced by `firestore.rules` so messages can **only** be deleted after `request.time.toMillis() >= existing().expiresAtMillis`.
- **Encrypted Voice Messaging Engine**:
  - `VoiceMessagingEngine.kt` records AAC `.m4a` audio (44.1 kHz, 128 kbps) to `cacheDir` on press-and-hold, discards clips shorter than 1 second, encrypts audio bytes with AES-256-GCM before upload, and provides single-stream playback with clean `MediaRecorder`/`MediaPlayer` lifecycle cleanup.
- **Zero-Leak Storage & Backup**:
  - `AndroidManifest.xml` sets `android:allowBackup="false"`, and `data_extraction_rules.xml` / `backup_rules.xml` exclude `sharedpref`, `database`, and `datastore/` from cloud backups and device transfers.
- **Hardened Firebase Rules**:
  - `firestore.rules`: Enforces default-deny, strict PII isolation (`/users/{userId}` owner-only; `/user_directory/{userId}` non-PII public discovery), strict participant scoping on `/chats/{chatId}` and `/messages/{messageId}`, schema validation, and immutable messages except post-expiry deletion.
  - `firebase/database.rules.json` & `firebase/storage.rules`: Hardened reference rules included if you also enable Realtime Database or Firebase Storage in your own Firebase project.

---

## Theme & Bilingual RTL Support

- Strictly enforced dark palette: Primary `#121212`, Surface `#1E1E1E`, Accent `#E53935`, Text `#FFFFFF` / `#BDBDBD`, `12dp–16dp` rounded corners.
- Bundled local fonts (`Cairo` for Latin/Arabic + `JetBrains Mono` for timestamps/fingerprints).
- Live in-app **English (LTR)** and **Arabic (RTL)** switching in Settings.

---

## Build & Export Instructions

### 1. Exporting from Google AI Studio
Use the **Export / Download ZIP** option in AI Studio to download the complete project archive.

### 2. Firebase Setup (When Using Your Own Firebase Project)
1. Place your downloaded `google-services.json` inside `app/`.
2. Update `app/src/main/res/values/firebase_applet_config.xml` with your Firestore database ID (or `"default"` if using the default Firestore database).
3. If you want to change the package/application ID (for example to `com.mralios.chat`), update `applicationId` in `app/build.gradle.kts` to match your `google-services.json` package name.
4. Deploy `firestore.rules` in Firebase Console (or via `firebase deploy --only firestore:rules`), and optionally apply `firebase/database.rules.json` / `firebase/storage.rules`.
5. In **Firebase Console -> Authentication -> Sign-in method**, ensure **Google** is enabled (and add your debug/release SHA-1 fingerprint).

### 3. Local Android Studio / Gradle APK Build
```bash
# Build Debug APK
gradle assembleDebug
# Output: app/build/outputs/apk/debug/app-debug.apk

# Run Unit & Robolectric Tests
gradle :app:testDebugUnitTest
```

### 4. GitHub Actions Auto-APK Workflow
Push this repository to GitHub with `main` as your branch (or trigger **Actions -> Build Android Debug APK -> Run workflow**):
- Workflow file: `.github/workflows/build-apk.yml`
- Runs on `ubuntu-latest` with JDK 17.
- Executes `gradle assembleDebug` and uploads `app/build/outputs/apk/debug/app-debug.apk` as artifact **`MraliosChat-debug`**.
- Commented release-signing steps are included in `.github/workflows/build-apk.yml` when you are ready to configure `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, and `KEY_PASSWORD` secrets.
